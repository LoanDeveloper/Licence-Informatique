/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitor;

import tp1.Article;
import tp1.Catalogue;

/**
 *
 * @author loant
 */
public class CalculStock implements Visitor{
    public void visitCatalogue(Catalogue catalogue){
        
    }
    public void visitArticle(Article article){
        
    }
}
