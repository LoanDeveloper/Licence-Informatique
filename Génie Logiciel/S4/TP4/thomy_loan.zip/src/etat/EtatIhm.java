package etat;

import tp1.Catalogue;
/**
 *
 * @author loant
 */
public abstract class EtatIhm {

    public EtatIhm() {
    }
    
    
    public abstract void afficherMenu(Catalogue cat);
}
