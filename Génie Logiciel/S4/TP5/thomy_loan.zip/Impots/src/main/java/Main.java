/**
 *
 * @author loant
 */
public class Main {
     
    public static void main(String[] args) throws Exception{
        
        CalculImpot calculImpot = new CalculImpot();
        System.out.println(calculImpot.calcul(187772,1));
        
    }
    
}
