package etat;

import tp1.Catalogue;
/**
 *
 * @author loant
 */
public class EtatIhmChoix extends EtatIhm{
    
    public void afficherMenu(Catalogue cat){
        
    }
    
    public EtatIhmChoix(Controleur c){
        
    }
}
