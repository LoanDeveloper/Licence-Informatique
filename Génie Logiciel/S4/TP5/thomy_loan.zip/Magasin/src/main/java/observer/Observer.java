package observer;

/**
 *
 * @author loant
 */
public interface Observer {
    
    public void update(Observable obs, Object arg);
    
}
