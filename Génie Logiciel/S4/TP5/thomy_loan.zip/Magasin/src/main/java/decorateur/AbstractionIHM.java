package decorateur;

/**
 *
 * @author loant
 */
public interface AbstractionIHM {
    
    public void afficherMenu();
}
