public enum Tarifs {
    NORMAL,
    REDUIT,
    ABONNEMENT
}
