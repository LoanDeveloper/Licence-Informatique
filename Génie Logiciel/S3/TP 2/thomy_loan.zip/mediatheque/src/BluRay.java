public class BluRay implements Documents{
    private genreBluRay genre;
    private int duree;

    public BluRay(genreBluRay genre, int duree) {
        this.genre = genre;
        this.duree = duree;
    }
}
