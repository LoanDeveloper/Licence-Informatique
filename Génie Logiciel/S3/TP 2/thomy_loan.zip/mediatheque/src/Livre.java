public class Livre implements Documents {
    private genreLivres genre;

    public Livre(genreLivres genre) {
        this.genre = genre;
    }
}
