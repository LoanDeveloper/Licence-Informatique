public enum genreBluRay {
    DOCUMENTAIRE,
    COMEDIE,
    FANTASTIQUE,
    AUTRE
}
