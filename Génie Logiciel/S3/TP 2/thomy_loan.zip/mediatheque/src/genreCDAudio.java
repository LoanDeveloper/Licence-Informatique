public enum genreCDAudio {
    CLASSIQUE,
    VARIETE_FRANCAISE,
    AUTRE
}
