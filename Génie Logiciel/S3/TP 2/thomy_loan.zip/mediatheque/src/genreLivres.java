public enum genreLivres {
    ROMAN,
    POLICIER,
    AUTRE
}
