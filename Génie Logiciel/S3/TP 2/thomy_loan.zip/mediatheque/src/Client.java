public class Client {
    protected String nom;
    protected String prenom;
    protected String adresse;

    public Client(String nom, String prenom, String adresse) {
        this.nom = nom;
        this.prenom = prenom;
        this.adresse = adresse;
    }
}
