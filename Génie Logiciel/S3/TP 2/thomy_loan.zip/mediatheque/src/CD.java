public class CD implements Documents{
    private genreCDAudio genre;

    public CD(genreCDAudio genre) {
        this.genre = genre;
    }
}
