#!/usr/bin/env sh

docker-compose stop