#!/usr/bin/env sh

mvn clean package -DskipTests
