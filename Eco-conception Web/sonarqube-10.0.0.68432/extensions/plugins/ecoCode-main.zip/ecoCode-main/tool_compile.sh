#!/usr/bin/env sh

mvn clean compile
