#!/usr/bin/env sh

# private TOKEN to change once generated in your local SonarQube
TOKEN=MY_TOKEN_TO_REPLACE docker-compose up --build -d