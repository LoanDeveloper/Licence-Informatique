#!/usr/bin/env sh

docker-compose logs -f