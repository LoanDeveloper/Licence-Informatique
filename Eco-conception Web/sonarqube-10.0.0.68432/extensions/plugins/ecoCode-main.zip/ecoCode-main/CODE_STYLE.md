Please read common [CODE_STYLE.md](https://github.com/green-code-initiative/ecoCode-common/blob/main/doc/CODE_STYLE.md) in `ecoCode-common` repository.
