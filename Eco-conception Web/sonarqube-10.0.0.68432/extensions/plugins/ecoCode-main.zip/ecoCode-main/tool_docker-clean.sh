#!/usr/bin/env sh

docker-compose down --volumes 