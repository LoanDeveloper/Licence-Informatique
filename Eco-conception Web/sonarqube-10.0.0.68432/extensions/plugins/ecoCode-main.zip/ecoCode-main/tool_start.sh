#!/usr/bin/env sh

docker-compose start