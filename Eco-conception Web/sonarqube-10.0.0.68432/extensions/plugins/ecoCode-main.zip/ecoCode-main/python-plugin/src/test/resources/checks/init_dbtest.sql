DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT NOT NULL AUTO_INCREMENT, 
  name VARCHAR(255),
  PRIMARY KEY (id)
);

INSERT INTO users(name) VALUES('a');
INSERT INTO users(name) VALUES('b');
INSERT INTO users(name) VALUES('c');
INSERT INTO users(name) VALUES('d');
INSERT INTO users(name) VALUES('e');
INSERT INTO users(name) VALUES('f');
INSERT INTO users(name) VALUES('g');
INSERT INTO users(name) VALUES('h');
INSERT INTO users(name) VALUES('i');
INSERT INTO users(name) VALUES('j');
INSERT INTO users(name) VALUES('k');
INSERT INTO users(name) VALUES('l');
INSERT INTO users(name) VALUES('m');
INSERT INTO users(name) VALUES('n');
INSERT INTO users(name) VALUES('o');
INSERT INTO users(name) VALUES('p');
INSERT INTO users(name) VALUES('q');
INSERT INTO users(name) VALUES('r');
INSERT INTO users(name) VALUES('s');
INSERT INTO users(name) VALUES('t');
INSERT INTO users(name) VALUES('u');
INSERT INTO users(name) VALUES('v');
INSERT INTO users(name) VALUES('w');
INSERT INTO users(name) VALUES('x');
INSERT INTO users(name) VALUES('y');
INSERT INTO users(name) VALUES('z');
