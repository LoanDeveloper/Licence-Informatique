
# Migration TODOs

## IDEAS

.. to tranform into issues ?

- [IN PROGRESS] check `pom.xml` dependencies (usefulness, scope, versions)
  - [DONE] first clean, check scopes, factorization
  - check usefulness
  - upgrade versions
- enable github `dependabot` to create automatically PR with version upgrades of dependencides (when all dependencies will be ok)
