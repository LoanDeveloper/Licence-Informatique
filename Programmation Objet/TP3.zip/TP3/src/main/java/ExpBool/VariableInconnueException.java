package ExpBool;

/**
 *
 */
public class VariableInconnueException extends Exception
{
    public VariableInconnueException()
    {
    }

    public VariableInconnueException(String msg)
    {
        super(msg);
    }
}
