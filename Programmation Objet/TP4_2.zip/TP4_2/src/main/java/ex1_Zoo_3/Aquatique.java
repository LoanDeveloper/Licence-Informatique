package ex1_Zoo_3;

public interface Aquatique {
    public boolean eauDouce();
}
