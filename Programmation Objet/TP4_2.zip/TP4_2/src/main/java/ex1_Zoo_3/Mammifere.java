package ex1_Zoo_3;

public interface Mammifere extends Animals {
    public boolean estCarnivore();

}
