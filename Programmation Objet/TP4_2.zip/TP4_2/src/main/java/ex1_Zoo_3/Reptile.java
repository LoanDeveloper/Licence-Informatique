package ex1_Zoo_3;

public interface Reptile extends Animals{
    public boolean estVenimeux();
}
