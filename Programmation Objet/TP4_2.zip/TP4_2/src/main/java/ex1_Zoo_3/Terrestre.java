package ex1_Zoo_3;

public interface Terrestre{
    public String habitat();
}
