package ex1_Zoo_3;

public interface Animals {
    public String donneNom();
}
