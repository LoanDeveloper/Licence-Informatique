package TP4.ex1_Zoo_2;
import java.util.ArrayList;

/*
public class Main {


    public static void main(String[] args) {
        int cptReptiles = 0;
        int cptTerrestre = 0;
        
        ArrayList<Animal> animaux = new ArrayList<>();
        
        MammifereAquatique ma = new MammifereAquatique(false, true,"Baleine");
        MammifereTerrestre mt = new MammifereTerrestre("plaine",false,"cheval");
        ReptileAquatique ra = new ReptileAquatique(true, true, "Vipère");
        ReptileTerrestre rt = new ReptileTerrestre("terre", true, "Vipère");

        animaux.add(ma);
        animaux.add(mt);
        animaux.add(ra);
        animaux.add(rt);
        
        for (Animal a : animaux){
            if (a instanceof ReptileAquatique || a instanceof ReptileTerrestre){
                cptReptiles++;
            }
            if (a instanceof MammifereTerrestre || a instanceof ReptileTerrestre){
                cptTerrestre++;
            } 
        }
        
        System.out.println("cptReptiles : " + cptReptiles);
        System.out.println("cptTerrestre : " + cptTerrestre);
    }
    
}
*/