package TP4.ex1_Zoo_2;

public interface Aquatique {
}
