/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TP4.ex1_Zoo_2;

/*
public class Mammifere extends Animal{
    private boolean carnivore;

    public Mammifere(boolean carnivore, String nomEspece) {
        super(nomEspece);
        this.carnivore = carnivore;
    }

}
*/