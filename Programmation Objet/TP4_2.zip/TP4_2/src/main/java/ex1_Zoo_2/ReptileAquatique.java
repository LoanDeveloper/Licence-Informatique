/*
package TP4.ex1_Zoo_1;

public class ReptileAquatique extends Reptile
{  
   private boolean eauDouce;

    public ReptileAquatique(boolean eauDouce, boolean venimeux, String nomEspece) {
        super(venimeux, nomEspece);
        this.eauDouce = eauDouce;
    }
   
}
*/