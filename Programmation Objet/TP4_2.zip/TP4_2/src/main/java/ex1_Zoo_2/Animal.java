/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
package TP4.ex1_Zoo_1;

public class Animal {
    private String nomEspece;

    public Animal(String nomEspece) {
        this.nomEspece = nomEspece;
    }
    
}
*/