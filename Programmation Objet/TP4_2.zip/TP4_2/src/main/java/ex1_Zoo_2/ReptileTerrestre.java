/**
 * Classe représentant un reptile terrestre caracterise par :
 * - un nom d'espece,
 * - un indicateur booleen precisant si le reptile est venimeux,
 * - un nom d'habitat (biotope).
 */
/*
package TP4.ex1_Zoo_1;
public class ReptileTerrestre extends Reptile
{
   private String habitat;

    public ReptileTerrestre(String habitat, boolean venimeux, String nomEspece) {
        super(venimeux, nomEspece);
        this.habitat = habitat;
    }

  
   
}
*/