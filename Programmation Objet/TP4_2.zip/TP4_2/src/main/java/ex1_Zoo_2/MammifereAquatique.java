
/*
package TP4.ex1_Zoo_1;

public class MammifereAquatique extends Mammifere
{
   private boolean eauDouce;

    public MammifereAquatique(boolean eauDouce, boolean carnivore, String nomEspece) {
        super(carnivore, nomEspece);
        this.eauDouce = eauDouce;
    }


}
*/