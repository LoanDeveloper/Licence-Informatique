/*package ex1_Zoo_1;

public abstract class Reptile extends Animal{
    private boolean venimeux;

    public Reptile(boolean venimeux, String nomEspece) {
        super(nomEspece);
        this.venimeux = venimeux;
    }
    
}
*/