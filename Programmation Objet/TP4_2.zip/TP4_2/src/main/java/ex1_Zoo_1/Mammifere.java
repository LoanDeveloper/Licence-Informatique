package ex1_Zoo_1;
/*
public abstract class Mammifere extends Animal{
    private boolean carnivore;

    public Mammifere(boolean carnivore, String nomEspece) {
        super(nomEspece);
        this.carnivore = carnivore;
    }
}*/
