/*
package ex1_Zoo_1;
public abstract class Animal {
    private String nomEspece;

    public Animal(String nomEspece) {
        this.nomEspece = nomEspece;
    }
    
}
*/