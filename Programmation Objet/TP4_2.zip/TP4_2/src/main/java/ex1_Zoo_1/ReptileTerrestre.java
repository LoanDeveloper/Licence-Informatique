/*package ex1_Zoo_1;
public class ReptileTerrestre extends Reptile
{
   private String habitat;

    public ReptileTerrestre(String habitat, boolean venimeux, String nomEspece) {
        super(venimeux, nomEspece);
        this.habitat = habitat;
    }
}*/
